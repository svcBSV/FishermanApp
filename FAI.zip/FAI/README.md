# FishermanApp
Alpha Chrome Extension for creating and ordinal bookmarks from txids (also supports hodlocker messages)
